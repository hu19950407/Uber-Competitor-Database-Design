USE master;
GO

IF  DB_ID('UberCompetitor') IS NOT NULL
    DROP DATABASE UberCompetitor;
GO

CREATE DATABASE UberCompetitor;
GO

USE UberCompetitor;

-- create the tables for the database
CREATE TABLE Customers(
   CustomerID         INT            PRIMARY KEY   IDENTITY(1,1),
   CustomerFirstName  VARCHAR(50)    NOT NULL,
   CustomerLastName   VARCHAR(50)    NOT NULL,
   UserName           VARCHAR(50)    NOT NULL,
   Email              VARCHAR(255)   NOT NULL      UNIQUE,
   PhoneNumber        VARCHAR(12)    NOT NULL      UNIQUE,
   Status             VARCHAR(8)     NOT NULL      CHECK (Status = 'Active' OR Status = 'Inactive'),
   LastTripDate       DATE           NOT NULL,
   NumberOfTrips      INT            NOT NULL
);

CREATE TABLE CustomerAddress(
   CustomerID         INT            PRIMARY KEY,
   Address            VARCHAR(60)    NOT NULL,
   City               VARCHAR(40)    NOT NULL,
   State              VARCHAR(2)     NOT NULL,
   ZipCode            VARCHAR(10)    NOT NULL
);

CREATE TABLE CustomerCreditCards(
   CardID             INT            PRIMARY KEY   IDENTITY(1,1),
   CreditCardNumber   VARCHAR(19)    NOT NULL      UNIQUE,
   CustomerID         INT            REFERENCES Customers(CustomerID)
);


CREATE TABLE Drivers(
   DriverID           INT            PRIMARY KEY   IDENTITY(1,1),
   DriverFirstName    VARCHAR(50)    NOT NULL,
   DriverLastName     VARCHAR(50)    NOT NULL,
   Status             VARCHAR(25)    NOT NULL,
   DateOfBirth        DATE           NOT NULL,
   StartDate          DATE           NULL,
   SSN                VARCHAR(11)    NOT NULL,
   AccountNo          VARCHAR(19)    NOT NULL,
   TypeOfAccount      VARCHAR(8)     NOT NULL      CHECK(TypeOfAccount = 'checking' OR TypeOfAccount = 'saving')
);


CREATE TABLE TripsAndReservations(
   OrderID            INT            PRIMARY KEY   IDENTITY(1,1),
   CustomerID         INT            REFERENCES  Customers(CustomerID),
   DriverID           INT            REFERENCES  Drivers(DriverID),
   BookedDate         DATE           NOT NULL,
   PickUpTime         DATETIME       NOT NULL,
   DropOffTime        DATETIME       NOT NULL,
   Completed          VARCHAR(3)     NOT NULL      CHECK(Completed = 'Yes' OR Completed = 'No'),
   PickUpAddress      VARCHAR(255)   NOT NULL,
   DropOffAddress     VARCHAR(255)   NOT NULL,
   NumberOfPeople     INT            NOT NULL,
   NumberOfBags       INT            NOT NULL,
   CustomerNote       TEXT           NULL,
   CostPaid           MONEY          NOT NULL,
   Tips               MONEY          NULL      
);

                
CREATE TABLE CustomerRating(
   OrderID            INT            PRIMARY KEY,
   CustomerID         INT            REFERENCES  Customers(CustomerID),
   ReviewDate         DATE           NULL,
   Score              FLOAT          NULL,
   CustomerComment    TEXT           NULL
);

CREATE TABLE DriverRating(
   OrderID            INT            PRIMARY KEY,
   DriverID           INT            REFERENCES  Drivers(DriverID),
   ReviewDate         DATE           NULL,
   Score              FLOAT          NULL,
   DriverComment      TEXT           NULL
);

CREATE TABLE BanksInformation(
   BankID            INT            PRIMARY KEY   IDENTITY(1,1),
   BankName          VARCHAR(60)    NOT NULL,
   Routing           VARCHAR(20)    NOT NULL
);

CREATE TABLE PaymentInformation(
   OrderID           INT            PRIMARY KEY,
   BankID            INT            REFERENCES  BanksInformation(BankID),
   DriverID          INT            REFERENCES  Drivers(DriverID),
   CardID            INT            REFERENCES  CustomerCreditCards(CardID),
   PaidDate          DATE           NOT NULL
);

CREATE TABLE DriverAddress(
   DriverID          INT            PRIMARY KEY,
   Address           VARCHAR(60)    NOT NULL,
   City              VARCHAR(40)    NOT NULL,
   State             VARCHAR(2)     NOT NULL,
   ZipCode           VARCHAR(10)    NOT NULL         
);

CREATE TABLE DriverInsurence(
   DriverID          INT            PRIMARY KEY,
   Company           VARCHAR(50)    NOT NULL,
   PolicyNumber      VARCHAR(20)    NOT NULL,
   DateOfIssue       DATE           NOT NULL,
   DateOfExpiry      DATE           NOT NULL
);

CREATE TABLE CarInformation(
   DriverID           INT            PRIMARY KEY,
   Make               VARCHAR(20)    NOT NULL,
   Model              VARCHAR(20)    NOT NULL,
   Year               VARCHAR(4)     NOT NULL,
   Color              VARCHAR(10)    NOT NULL,
   CarClass           VARCHAR(10)    NOT NULL,
   NumberOfPassengers INT            NOT NULL,
   NumberOfBags       INT            NOT NULL
);

CREATE TABLE DriverLicense(
   DriverID           INT            PRIMARY KEY,
   State              VARCHAR(2)     NOT NULL,
   DateOfIssue        DATE           NOT NULL,
   DateOfExpiry       DATE           NOT NULL,
   LicenseNo          VARCHAR(20)    NOT NULL
);

SET IDENTITY_INSERT Customers ON;

INSERT INTO Customers (CustomerID,CustomerFirstName,CustomerLastName,UserName,Email,PhoneNumber,Status,LastTripDate,NumberOfTrips) VALUES
(1,'Allan','Sherwood','Arika','allan.sherwood@yahoo.com','800-555-1205','Active','2019-01-21',3),
(2,'Erin','Valentino','KyleM2303','erinv@gmail.com','559-555-1551','Active','2018-12-12',2),
(3,'Donette','Foller','ShadowDarter','donette.foller@cox.net','559-555-2993','Active','2019-03-28',1),
(4,'Willard','Kolmetz','AlinaBanana','willard@hotmail.com','614-555-4435','Inactive','2014-01-30',2),
(5,'Roxane','Campain','Ambulance','roxane@hotmail.com','810-555-3700','Active','2019-04-20',4)

SET IDENTITY_INSERT Customers OFF;


INSERT INTO CustomerAddress(CustomerID,Address,City,State,ZipCode) VALUES
(1,'4221 W Sierra Madre #104','Washington','IA','52353'),
(2,'121 E Front St - 4th Floor','Traverse City','MI','49684'),
(3,'3649 W Beechwood Ave #101','Fresno','CA','93711'),
(4,'117 W Micheltorena Top Floor','Santa Barbara','CA','93101'),
(5,'3502 W Greenway #7','Phoenix','AZ','85023')


SET IDENTITY_INSERT CustomerCreditCards ON;

INSERT INTO CustomerCreditCards (CardID,CustomerID,CreditCardNumber) VALUES
(1,1,'4111 1670 2706 5473'),
(2,1,'5500 5051 2367 4459'),
(3,2,'3400 3254 5213 4569'),
(4,3,'4111 4167 5213 4566'),
(5,3,'5500 5423 5684 4869'),
(6,3,'6217 1134 5213 2210'),
(7,4,'6217 3349 5234 7802'), 
(8,5,'4111 1121 1235 5246')

SET IDENTITY_INSERT CustomerCreditCards OFF;

SET IDENTITY_INSERT Drivers ON;

INSERT INTO Drivers (DriverID,DriverFirstName,DriverLastName,Status,DateOfBirth,StartDate,SSN,AccountNo,TypeOfAccount) VALUES
(1,'Jeanice','Claucherty','Working-available','1985-01-17','2017-05-09','135-86-8364','4111 1203 1153 5598','checking'),
(2,'Britt','Galam','Working-available','1990-07-21','2018-04-30','122-54-1312','6217 1154 5219 6587','checking'),
(3,'Daniela','Comnick','Working-available','1995-11-21','2017-05-12','122-38-4543','5500 5213 4598 6875','checking'),
(4,'Jess','Chaffins','Working-off','1980-05-04','2018-04-25','112-25-4584','3400 2545 9875 3154','checking'),
(5,'Sharen','Bourbon','Inactive','1996-11-12',null,'112-48-5612','3400 2546 8759 6452','saving'),
(6,'Roslyn','Chavous','Working-available','1990-07-24','2018-05-29','124-12-5498','4111 1215 4578 5624','checking'),
(7,'Glory','Schieler','Working-available','1994-02-03','2018-05-03','122-48-9621','6217 2358 4569 2154','checking'),
(8,'Shawna','Palaspas','Working-available','1995-07-21','2017-02-20','154-545-875','6217 5254 5521 2542','checking'),
(9,'Melissa','Wiklund','Working-available','1991-04-21','2018-01-02','185-457-547','6217 5245 1254 2575','checking')
SET IDENTITY_INSERT Drivers OFF;


INSERT INTO DriverAddress (DriverID,Address,City,State,ZipCode) VALUES
(1,'3467 W Shaw Ave #103','Fresno','CA','93711'),
(2,'5411 Jackson Road','Ann Arbor','MI','48106'),
(3,'1617 W. Shaw Avenue','Fresno','CA','93711'),
(4,'Book Marketing Update','Fairfield','IA','52556'),
(5,'4545 Glenmeade Lane','Auburn Hills','MI','48326'),
(6,'PO Box 78225','Phoenix','AZ','85062'),
(7,'Business Mastercard','Phoenix','AZ','85038'),
(8,'PO Box 205','Fairfield','IA','52556'),
(9,'PO Box 1124','Ann Arbor','MI','48106')


INSERT INTO DriverInsurence (DriverID,Company,PolicyNumber,DateOfIssue,DateOfExpiry) VALUES
(1,'Allstate','926487596','2018-09-01','2019-09-01'),
(2,'Esurance','685215962','2019-01-01','2019-07-01'),
(3,'Allstate','521356875','2018-12-30','2019-06-30'),
(4,'Liberty Mutual','598648752','2019-02-02','2019-08-02'),
(5,'Geico','879654852','2019-04-01','2020-04-01'),
(6,'Farmers','875975468','2019-02-03','2019-08-03'),
(7,'Ameriprise','825475965','2019-01-30','2020-01-30'),
(8,'Farmers','548569752','2018-11-21','2019-05-21'),
(9,'Geico','879562548','2019-02-11','2019-08-11')

INSERT INTO CarInformation (DriverID,Make,Model,Year,Color,CarClass,NumberOfPassengers,NumberOfBags) VALUES
(1,'Honda','Civic','2016','Black','Sedan',4,4),
(2,'Audi','A4','2014','White','Sedan',4,4),
(3,'Ford','Focus','2015','Blue','Sedan',4,4),
(4,'Jeep','Compass','2017','Red','SUV',5,5),
(5,'Mazda','CX-9','2018','Black','SUV',7,7),
(6,'Chevrolet','Silverado','2018','Black','Truck',5,10),
(7,'Chrysler','Pacifica','2016','White','Van',10,10),
(8,'Honda','Civic','2014','Red','Sedan',4,4),
(9,'Mazda','CX-5','2018','Red','SUV',5,5)



INSERT INTO DriverLicense (DriverID,State,DateOfIssue,DateOfExpiry,LicenseNo) VALUES
(1,'CA','2003-01-17','2023-01-17','385 254 869'),
(2,'MI','2008-07-21','2028-07-21','658 524 546'),
(3,'CA','2013-11-21','2023-11-21','568 548 854'),
(4,'IA','1998-05-04','2028-05-04','254 856 954'),
(5,'MI','2014-11-12','2024-11-12','858 754 515'),
(6,'AZ','2008-07-24','2028-07-24','857 954 542'),
(7,'AZ','2012-02-03','2022-02-03','854 987 524'),
(8,'IA','2013-07-21','2023-07-21','987 582 562'),
(9,'MI','2009-04-21','2029-04-21','878 524 698')

SET IDENTITY_INSERT TripsAndReservations ON;

INSERT INTO TripsAndReservations (OrderID,CustomerID,DriverID,BookedDate,PickUpTime,DropOffTime,Completed,
                                  PickUpAddress,DropOffAddress,NumberOfPeople,NumberOfBags,CustomerNote,
								  CostPaid,Tips) VALUES
(1,1,4,'2018-05-21','2018-05-21 12:10:10','2018-05-21 12:50:40','Yes','4221 W Sierra Madre #104','828 S Broadway',1,1,NULL,12.45,1.86),
(2,1,8,'2018-09-14','2018-09-14 10:45:21','2018-09-14 11:30:20','Yes','4221 W Sierra Madre #104','3502 W Greenway #7',2,4,NULL,17.45,3.49),
(3,1,4,'2019-01-24','2019-01-24 15:32:42','2019-01-24 16:40:24','Yes','4221 W Sierra Madre #104','4697 W Jacquelyn Ave',1,2,NULL,24.5,4.9),
(4,2,2,'2018-05-12','2018-05-12 08:21:20','2018-05-12 10:10:21','Yes','121 E Front St - 4th Floor','627 Aviation Way',1,1,NULL,33.81,6.76),
(5,2,9,'2018-12-12','2018-12-12 20:17:15','2018-12-12 21:00:01','Yes','121 E Front St - 4th Floor','722 E Olive Ave',3,2,NULL,15.8,3.16),
(6,3,3,'2019-02-25','2019-02-25 13:21:46','2019-02-25 14:25:31','Yes','3649 W Beechwood Ave #101','27371 Valderas',2,2,NULL,20.21,4.04),
(7,4,3,'2019-03-21','2019-03-21 10:24:25','2019-03-21 10:50:32','Yes','117 W Micheltorena Top Floor','Ohio Valley Litho Division',1,0,NULL,10.8,2.16),
(8,4,1,'2018-02-12','2018-02-12 17:24:23','2018-02-12 18:21:45','Yes','117 W Micheltorena Top Floor','PO Box 87373',1,2,NULL,20.4,4.08),
(9,5,6,'2018-06-21','2018-06-21 16:45:45','2018-06-21 17:10:12','Yes','3502 W Greenway #7','2384 E Gettysburg',2,3,NULL,11.5,2.3),
(10,5,7,'2018-07-12','2018-07-12 11:50:21','2018-07-12 12:45:21','Yes','3502 W Greenway #7','4 Cornwall Dr Ste 102',1,1,NULL,10.5,2.1),
(11,5,6,'2018-09-25','2018-09-25 14:25:45','2018-09-25 15:00:21','Yes','3502 W Greenway #7','Library Of Congress',1,3,NULL,8.45,1.69),
(12,5,7,'2018-11-21','2018-11-21 08:11:12','2018-11-21 09:05:21','Yes','3502 W Greenway #7','3000 Cindel Drive',1,2,NULL,10.1,2.02)

SET IDENTITY_INSERT TripsAndReservations OFF;

INSERT INTO CustomerRating (OrderID,CustomerID,ReviewDate,Score,CustomerComment) VALUES
(1,1,NULL,NULL,NULL),
(2,1,'2018-09-14',4.9,'Great guy, thank you.'),
(3,1,'2019-01-25',5.0,'Safe and reliable thanks.'),
(4,2,'2018-05-12',4.6,'Thanks for the ride and being so nice!'),
(5,2,NULL,NULL,NULL),
(6,3,'2019-02-25',4.7,'Awesome, mom was jealous.'),
(7,4,'2019-03-21',5.0,'Thank you for making great conversation.'),
(8,4,'2018-02-12',4.9,'So nice!!!!!'),
(9,5,'2018-06-21',4.8,'Very friendly. Good ride.'),
(10,5,'2018-07-12',4.7,'Excellent service, good thanks.'),
(11,5,'2018-09-25',2.0,'That was a terrible trip.'),
(12,5,'2018-11-21',4.9,'Great guy, super friendly.')

INSERT INTO DriverRating (OrderID,DriverID,ReviewDate,Score,DriverComment) VALUES
(1,4,'2018-05-21',5.0,'Nice guys!!!!!'),
(2,8,'2018-09-14',4.8,'Thank for your patient.'),
(3,4,'2019-01-24',4.9,'Very talkative.'),
(4,2,NULL,NULL,NULL),
(5,9,'2018-12-12',4.6,'Good guy!!'),
(6,3,'2019-02-25',2.1,'Terrible guys, noisy and dirty.'),
(7,3,'2019-03-21',4.0,'Not bad.'),
(8,1,'2018-02-12',4.7,'Super nice and friendly!!'),
(9,6,NULL,NULL,NULL),
(10,7,NULL,NULL,NULL),
(11,6,'2018-09-25',5.0,'Thanks for your help.'),
(12,7,'2018-11-21',4.9,'Nice guys!')

SET IDENTITY_INSERT BanksInformation ON;

INSERT INTO BanksInformation (BankID,Routing,BankName) VALUES
(1,'022254111','Chase'),
(2,'215485500','Key Bank'),
(3,'254873400','Bank of America'),
(4,'254696217','Citibank')

SET IDENTITY_INSERT BanksInformation OFF;

INSERT INTO PaymentInformation (OrderID,BankID,DriverID,CardID,PaidDate) VALUES
(1,1,4,1,'2018-05-21'),
(2,1,8,1,'2018-09-14'),
(3,2,4,2,'2019-01-24'),
(4,3,2,3,'2018-05-12'),
(5,3,9,3,'2018-12-12'),
(6,2,3,5,'2019-02-25'),
(7,4,3,7,'2019-03-21'),
(8,4,1,7,'2018-02-12'),
(9,1,6,8,'2018-06-21'),
(10,1,7,8,'2018-07-12'),
(11,1,6,8,'2018-09-25'),
(12,1,7,8,'2018-11-21')


